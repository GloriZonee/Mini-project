package com.example.skkn

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
